# Design System

## Single source of truth
Named design tokens are the source of truth consumed by design tools and frontend code.

## Tokens
- Brand colors
- Semantic status colors
- Neutral palette
- Typography
- 4/8px spacing
- Responsive breakpoints
- Elevation
- Radius
- Motion

## Shared components
Buttons, Inputs, Selects, Cards, Dialogs, Sheets, Toasts, Tables, Tabs, Navigation, Wallet Balance, Transaction Item, Status Badge, Confirmation, Error/Empty/Loading states.

## Accessibility
Focus states, focus trap/restoration, keyboard behavior, screen-reader semantics, sufficient contrast, reduced motion.
