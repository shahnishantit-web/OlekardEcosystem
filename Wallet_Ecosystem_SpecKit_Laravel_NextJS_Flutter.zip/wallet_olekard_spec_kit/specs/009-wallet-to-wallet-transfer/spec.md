# E09 — Wallet-to-Wallet Transfer

## Intent
This feature specification decomposes Epic E09 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-TRANSFER-001 — Initiate transfer (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Initiate transfer must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/initiate-transfer`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_001_REQUESTED; US_TRANSFER_001_SUCCEEDED; US_TRANSFER_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-002 — Search recipient (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Search recipient must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/search-recipient`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_002_REQUESTED; US_TRANSFER_002_SUCCEEDED; US_TRANSFER_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-003 — Validate recipient (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Validate recipient must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/validate-recipient`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_003_REQUESTED; US_TRANSFER_003_SUCCEEDED; US_TRANSFER_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-004 — Enter transfer amount (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Enter transfer amount must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/enter-transfer-amount`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_004_REQUESTED; US_TRANSFER_004_SUCCEEDED; US_TRANSFER_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-005 — Calculate transfer fee (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Calculate transfer fee must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/calculate-transfer-fee`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_005_REQUESTED; US_TRANSFER_005_SUCCEEDED; US_TRANSFER_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-006 — Validate balance (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Validate balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/validate-balance`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_006_REQUESTED; US_TRANSFER_006_SUCCEEDED; US_TRANSFER_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-007 — Validate transaction limit (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Validate transaction limit must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/validate-transaction-limit`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_007_REQUESTED; US_TRANSFER_007_SUCCEEDED; US_TRANSFER_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-008 — Perform risk evaluation (P0)
**Actor:** Risk engine / authorized risk officer

**Acceptance Criteria:** Perform risk evaluation must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/perform-risk-evaluation`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_008_REQUESTED; US_TRANSFER_008_SUCCEEDED; US_TRANSFER_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-009 — Confirm transfer (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Confirm transfer must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/confirm-transfer`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_009_REQUESTED; US_TRANSFER_009_SUCCEEDED; US_TRANSFER_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-010 — Authenticate transaction (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Authenticate transaction must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/authenticate-transaction`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_010_REQUESTED; US_TRANSFER_010_SUCCEEDED; US_TRANSFER_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-011 — Debit sender wallet (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Debit sender wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/debit-sender-wallet`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_011_REQUESTED; US_TRANSFER_011_SUCCEEDED; US_TRANSFER_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-012 — Credit recipient wallet (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Credit recipient wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/credit-recipient-wallet`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_012_REQUESTED; US_TRANSFER_012_SUCCEEDED; US_TRANSFER_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-013 — Generate ledger entries (P0)
**Actor:** Wallet / Ledger service

**Acceptance Criteria:** Generate ledger entries must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/generate-ledger-entries`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_013_REQUESTED; US_TRANSFER_013_SUCCEEDED; US_TRANSFER_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-014 — Complete transfer (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Complete transfer must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/complete-transfer`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_014_REQUESTED; US_TRANSFER_014_SUCCEEDED; US_TRANSFER_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-015 — Handle failed transfer (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Handle failed transfer must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/handle-failed-transfer`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_015_REQUESTED; US_TRANSFER_015_SUCCEEDED; US_TRANSFER_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-016 — Prevent duplicate transfer (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Prevent duplicate transfer must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/prevent-duplicate-transfer`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_016_REQUESTED; US_TRANSFER_016_SUCCEEDED; US_TRANSFER_016_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-017 — Generate transfer receipt (P1)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Generate transfer receipt must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/generate-transfer-receipt`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_017_REQUESTED; US_TRANSFER_017_SUCCEEDED; US_TRANSFER_017_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-018 — Notify sender (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Notify sender must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/notify-sender`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_018_REQUESTED; US_TRANSFER_018_SUCCEEDED; US_TRANSFER_018_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TRANSFER-019 — Notify recipient (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Notify recipient must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transfers/notify-recipient`

**DB Entities:** Transaction, Wallet, Journal, TransferParticipant

**Events:** US_TRANSFER_019_REQUESTED; US_TRANSFER_019_SUCCEEDED; US_TRANSFER_019_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
