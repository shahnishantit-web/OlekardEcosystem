# E28 — Configuration Management

## Intent
This feature specification decomposes Epic E28 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-CONFIG-001 — Configure transaction limits (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Configure transaction limits must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/configure-transaction-limits`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_001_REQUESTED; US_CONFIG_001_SUCCEEDED; US_CONFIG_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-002 — Configure wallet limits (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Configure wallet limits must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/configure-wallet-limits`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_002_REQUESTED; US_CONFIG_002_SUCCEEDED; US_CONFIG_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-003 — Configure fees (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Configure fees must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/configure-fees`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_003_REQUESTED; US_CONFIG_003_SUCCEEDED; US_CONFIG_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-004 — Configure commission (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Configure commission must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/configure-commission`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_004_REQUESTED; US_CONFIG_004_SUCCEEDED; US_CONFIG_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-005 — Configure KYC rules (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Configure KYC rules must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/configure-kyc-rules`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_005_REQUESTED; US_CONFIG_005_SUCCEEDED; US_CONFIG_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-006 — Configure risk rules (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Configure risk rules must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/configure-risk-rules`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_006_REQUESTED; US_CONFIG_006_SUCCEEDED; US_CONFIG_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-007 — Configure notification templates (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Configure notification templates must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/configure-notification-templates`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_007_REQUESTED; US_CONFIG_007_SUCCEEDED; US_CONFIG_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-008 — Configure supported currencies (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Configure supported currencies must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/configure-supported-currencies`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_008_REQUESTED; US_CONFIG_008_SUCCEEDED; US_CONFIG_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-009 — Configure supported countries (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Configure supported countries must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/configure-supported-countries`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_009_REQUESTED; US_CONFIG_009_SUCCEEDED; US_CONFIG_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-010 — Maintain configuration version history (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Maintain configuration version history must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/maintain-configuration-version-history`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_010_REQUESTED; US_CONFIG_010_SUCCEEDED; US_CONFIG_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CONFIG-011 — Require approval for critical configuration changes (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Require approval for critical configuration changes must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/config/require-approval-for-critical-configuration-changes`

**DB Entities:** Configuration, ConfigurationVersion, Approval

**Events:** US_CONFIG_011_REQUESTED; US_CONFIG_011_SUCCEEDED; US_CONFIG_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
