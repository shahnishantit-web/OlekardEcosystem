# E08 — Wallet Funding

## Intent
This feature specification decomposes Epic E08 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-FUND-001 — Initiate wallet funding (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Initiate wallet funding must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/initiate-wallet-funding`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_001_REQUESTED; US_FUND_001_SUCCEEDED; US_FUND_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-002 — Select funding method (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Select funding method must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/select-funding-method`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_002_REQUESTED; US_FUND_002_SUCCEEDED; US_FUND_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-003 — Enter funding amount (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Enter funding amount must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/enter-funding-amount`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_003_REQUESTED; US_FUND_003_SUCCEEDED; US_FUND_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-004 — Validate funding limits (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Validate funding limits must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/validate-funding-limits`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_004_REQUESTED; US_FUND_004_SUCCEEDED; US_FUND_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-005 — Calculate funding fee (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Calculate funding fee must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/calculate-funding-fee`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_005_REQUESTED; US_FUND_005_SUCCEEDED; US_FUND_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-006 — Confirm funding (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Confirm funding must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/confirm-funding`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_006_REQUESTED; US_FUND_006_SUCCEEDED; US_FUND_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-007 — Process funding payment (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Process funding payment must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/process-funding-payment`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_007_REQUESTED; US_FUND_007_SUCCEEDED; US_FUND_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-008 — Credit wallet after confirmed payment (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Credit wallet after confirmed payment must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/credit-wallet-after-confirmed-payment`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_008_REQUESTED; US_FUND_008_SUCCEEDED; US_FUND_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-009 — Handle failed funding (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Handle failed funding must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/handle-failed-funding`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_009_REQUESTED; US_FUND_009_SUCCEEDED; US_FUND_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-010 — Handle duplicate provider callback (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Handle duplicate provider callback must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/handle-duplicate-provider-callback`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_010_REQUESTED; US_FUND_010_SUCCEEDED; US_FUND_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-011 — Generate funding reference (P1)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Generate funding reference must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/generate-funding-reference`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_011_REQUESTED; US_FUND_011_SUCCEEDED; US_FUND_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-012 — Match incoming bank payment (P1)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Match incoming bank payment must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/match-incoming-bank-payment`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_012_REQUESTED; US_FUND_012_SUCCEEDED; US_FUND_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-013 — Auto-reconcile bank deposit (P1)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Auto-reconcile bank deposit must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/auto-reconcile-bank-deposit`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_013_REQUESTED; US_FUND_013_SUCCEEDED; US_FUND_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-014 — Handle unmatched deposit (P1)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Handle unmatched deposit must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/handle-unmatched-deposit`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_014_REQUESTED; US_FUND_014_SUCCEEDED; US_FUND_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-015 — Agent cash-in customer wallet (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Agent cash-in customer wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/agent-cash-in-customer-wallet`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_015_REQUESTED; US_FUND_015_SUCCEEDED; US_FUND_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-016 — Verify customer transaction (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Verify customer transaction must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/verify-customer-transaction`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_016_REQUESTED; US_FUND_016_SUCCEEDED; US_FUND_016_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-017 — Debit agent float (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Debit agent float must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/debit-agent-float`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_017_REQUESTED; US_FUND_017_SUCCEEDED; US_FUND_017_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-018 — Credit customer wallet (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Credit customer wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/credit-customer-wallet`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_018_REQUESTED; US_FUND_018_SUCCEEDED; US_FUND_018_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FUND-019 — Generate customer receipt (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Generate customer receipt must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/funding/generate-customer-receipt`

**DB Entities:** FundingTransaction, Payment, ProviderReference

**Events:** US_FUND_019_REQUESTED; US_FUND_019_SUCCEEDED; US_FUND_019_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
