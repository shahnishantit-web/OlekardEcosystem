# E33 — Admin Application

## Intent
This feature specification decomposes Epic E33 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-ADMINAPP-001 — View operational dashboard (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** View operational dashboard must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/view-operational-dashboard`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_001_REQUESTED; US_ADMINAPP_001_SUCCEEDED; US_ADMINAPP_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-002 — View financial dashboard (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** View financial dashboard must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/view-financial-dashboard`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_002_REQUESTED; US_ADMINAPP_002_SUCCEEDED; US_ADMINAPP_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-003 — View risk dashboard (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** View risk dashboard must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/view-risk-dashboard`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_003_REQUESTED; US_ADMINAPP_003_SUCCEEDED; US_ADMINAPP_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-004 — Search users (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Search users must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/search-users`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_004_REQUESTED; US_ADMINAPP_004_SUCCEEDED; US_ADMINAPP_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-005 — Manage users (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Manage users must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/manage-users`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_005_REQUESTED; US_ADMINAPP_005_SUCCEEDED; US_ADMINAPP_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-006 — Manage roles (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Manage roles must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/manage-roles`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_006_REQUESTED; US_ADMINAPP_006_SUCCEEDED; US_ADMINAPP_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-007 — Review KYC (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Review KYC must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/review-kyc`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_007_REQUESTED; US_ADMINAPP_007_SUCCEEDED; US_ADMINAPP_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-008 — Approve KYC (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Approve KYC must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/approve-kyc`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_008_REQUESTED; US_ADMINAPP_008_SUCCEEDED; US_ADMINAPP_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-009 — Reject KYC (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Reject KYC must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/reject-kyc`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_009_REQUESTED; US_ADMINAPP_009_SUCCEEDED; US_ADMINAPP_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-010 — Search wallets (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Search wallets must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/search-wallets`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_010_REQUESTED; US_ADMINAPP_010_SUCCEEDED; US_ADMINAPP_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-011 — Freeze wallet (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Freeze wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/freeze-wallet`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_011_REQUESTED; US_ADMINAPP_011_SUCCEEDED; US_ADMINAPP_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-012 — Unfreeze wallet (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Unfreeze wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/unfreeze-wallet`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_012_REQUESTED; US_ADMINAPP_012_SUCCEEDED; US_ADMINAPP_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-013 — Search transactions (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Search transactions must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/search-transactions`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_013_REQUESTED; US_ADMINAPP_013_SUCCEEDED; US_ADMINAPP_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-014 — Investigate transactions (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Investigate transactions must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/investigate-transactions`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_014_REQUESTED; US_ADMINAPP_014_SUCCEEDED; US_ADMINAPP_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-015 — Reverse transaction (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Reverse transaction must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/reverse-transaction`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_015_REQUESTED; US_ADMINAPP_015_SUCCEEDED; US_ADMINAPP_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-016 — Approve agent (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Approve agent must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/approve-agent`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_016_REQUESTED; US_ADMINAPP_016_SUCCEEDED; US_ADMINAPP_016_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-017 — Manage agent (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Manage agent must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/manage-agent`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_017_REQUESTED; US_ADMINAPP_017_SUCCEEDED; US_ADMINAPP_017_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-018 — Manage float (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Manage float must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/manage-float`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_018_REQUESTED; US_ADMINAPP_018_SUCCEEDED; US_ADMINAPP_018_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-019 — Reconciliation (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Reconciliation must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/reconciliation`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_019_REQUESTED; US_ADMINAPP_019_SUCCEEDED; US_ADMINAPP_019_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-020 — Settlement (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Settlement must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/settlement`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_020_REQUESTED; US_ADMINAPP_020_SUCCEEDED; US_ADMINAPP_020_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-021 — Audit (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Audit must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/audit`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_021_REQUESTED; US_ADMINAPP_021_SUCCEEDED; US_ADMINAPP_021_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-ADMINAPP-022 — Reports (P0)
**Actor:** Authorized Admin / Operations / Finance / Compliance user

**Acceptance Criteria:** Reports must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/admin-app/reports`

**DB Entities:** User, Wallet, Transaction, AdminAction

**Events:** US_ADMINAPP_022_REQUESTED; US_ADMINAPP_022_SUCCEEDED; US_ADMINAPP_022_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: relevant management screen, detail/drawer, confirmation, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
