# E03 — Device & Session Management

## Intent
This feature specification decomposes Epic E03 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-DEVICE-001 — Register device (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Register device must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/devices/register-device`

**DB Entities:** Device, DeviceTrust, Session, SecurityEvent

**Events:** US_DEVICE_001_REQUESTED; US_DEVICE_001_SUCCEEDED; US_DEVICE_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DEVICE-002 — Generate device fingerprint (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Generate device fingerprint must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/devices/generate-device-fingerprint`

**DB Entities:** Device, DeviceTrust, Session, SecurityEvent

**Events:** US_DEVICE_002_REQUESTED; US_DEVICE_002_SUCCEEDED; US_DEVICE_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DEVICE-003 — Mark trusted device (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Mark trusted device must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/devices/mark-trusted-device`

**DB Entities:** Device, DeviceTrust, Session, SecurityEvent

**Events:** US_DEVICE_003_REQUESTED; US_DEVICE_003_SUCCEEDED; US_DEVICE_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DEVICE-004 — View registered devices (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** View registered devices must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/devices/view-registered-devices`

**DB Entities:** Device, DeviceTrust, Session, SecurityEvent

**Events:** US_DEVICE_004_REQUESTED; US_DEVICE_004_SUCCEEDED; US_DEVICE_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DEVICE-005 — Remove registered device (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Remove registered device must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/devices/remove-registered-device`

**DB Entities:** Device, DeviceTrust, Session, SecurityEvent

**Events:** US_DEVICE_005_REQUESTED; US_DEVICE_005_SUCCEEDED; US_DEVICE_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DEVICE-006 — Detect device change (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Detect device change must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/devices/detect-device-change`

**DB Entities:** Device, DeviceTrust, Session, SecurityEvent

**Events:** US_DEVICE_006_REQUESTED; US_DEVICE_006_SUCCEEDED; US_DEVICE_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DEVICE-007 — Detect suspicious device (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Detect suspicious device must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/devices/detect-suspicious-device`

**DB Entities:** Device, DeviceTrust, Session, SecurityEvent

**Events:** US_DEVICE_007_REQUESTED; US_DEVICE_007_SUCCEEDED; US_DEVICE_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DEVICE-008 — Notify user about new device (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Notify user about new device must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/devices/notify-user-about-new-device`

**DB Entities:** Device, DeviceTrust, Session, SecurityEvent

**Events:** US_DEVICE_008_REQUESTED; US_DEVICE_008_SUCCEEDED; US_DEVICE_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DEVICE-009 — Block compromised device (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Block compromised device must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/devices/block-compromised-device`

**DB Entities:** Device, DeviceTrust, Session, SecurityEvent

**Events:** US_DEVICE_009_REQUESTED; US_DEVICE_009_SUCCEEDED; US_DEVICE_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
