# Tasks — E03 Device & Session Management

## Task groups

### 1. Specification & dependency validation
- [ ] Validate story dependencies and cross-epic contracts
- [ ] Identify any blocking TBDs without inventing values

### 2. Data & persistence
- [ ] Define/update PostgreSQL schema and migrations
- [ ] Add indexes, foreign keys and unique constraints

### 3. Backend domain/application implementation
- [ ] Implement domain rules
- [ ] Implement application services/use cases
- [ ] Implement authorization/policies
- [ ] Implement idempotency/concurrency controls where applicable

### 4. API
- [ ] Implement REST/OpenAPI contracts
- [ ] Implement validation/error handling
- [ ] Implement correlation IDs and audit hooks

### 5. Events/integrations
- [ ] Implement domain/integration events
- [ ] Implement reliable outbox/queue handling where applicable

### 6. UI
- [ ] Implement Next.js/Flutter screens where applicable
- [ ] Consume shared design tokens/components
- [ ] Implement loading/empty/error/success/security states

### 7. QA & security
- [ ] Unit tests
- [ ] Integration/API tests
- [ ] E2E/system tests
- [ ] Security tests
- [ ] Accessibility tests where applicable
- [ ] Performance/resilience tests where applicable

### 8. Documentation & release
- [ ] Update OpenAPI/contracts
- [ ] Update technical documentation
- [ ] Attach QA evidence
- [ ] Run `/speckit.analyze`
- [ ] Run `/speckit.converge` after implementation