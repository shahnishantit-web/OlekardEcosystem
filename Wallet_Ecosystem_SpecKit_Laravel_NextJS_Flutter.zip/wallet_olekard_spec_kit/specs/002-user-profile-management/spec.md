# E02 — User & Profile Management

## Intent
This feature specification decomposes Epic E02 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-USER-001 — View profile (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** View profile must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/view-profile`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_001_REQUESTED; US_USER_001_SUCCEEDED; US_USER_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-002 — Update personal information (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Update personal information must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/update-personal-information`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_002_REQUESTED; US_USER_002_SUCCEEDED; US_USER_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-003 — Update profile photo (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Update profile photo must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/update-profile-photo`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_003_REQUESTED; US_USER_003_SUCCEEDED; US_USER_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-004 — Update email (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Update email must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/update-email`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_004_REQUESTED; US_USER_004_SUCCEEDED; US_USER_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-005 — Change mobile number (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Change mobile number must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/change-mobile-number`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_005_REQUESTED; US_USER_005_SUCCEEDED; US_USER_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-006 — Verify changed mobile number (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Verify changed mobile number must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/verify-changed-mobile-number`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_006_REQUESTED; US_USER_006_SUCCEEDED; US_USER_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-007 — Verify changed email (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Verify changed email must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/verify-changed-email`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_007_REQUESTED; US_USER_007_SUCCEEDED; US_USER_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-008 — View account status (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** View account status must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/view-account-status`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_008_REQUESTED; US_USER_008_SUCCEEDED; US_USER_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-009 — Activate account (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Activate account must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/activate-account`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_009_REQUESTED; US_USER_009_SUCCEEDED; US_USER_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-010 — Suspend account (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Suspend account must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/suspend-account`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_010_REQUESTED; US_USER_010_SUCCEEDED; US_USER_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Privileged role + explicit action permission + maker-checker where configured

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-011 — Reactivate account (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Reactivate account must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/reactivate-account`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_011_REQUESTED; US_USER_011_SUCCEEDED; US_USER_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-012 — Permanently close account (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Permanently close account must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/permanently-close-account`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_012_REQUESTED; US_USER_012_SUCCEEDED; US_USER_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-013 — Request account closure (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Request account closure must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/request-account-closure`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_013_REQUESTED; US_USER_013_SUCCEEDED; US_USER_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-014 — Prevent closure with unresolved financial obligations (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Prevent closure with unresolved financial obligations must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/prevent-closure-with-unresolved-financial-obligations`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_014_REQUESTED; US_USER_014_SUCCEEDED; US_USER_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-USER-015 — Export personal account data (P2)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Export personal account data must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/users/export-personal-account-data`

**DB Entities:** User, UserProfile, AccountStatusHistory

**Events:** US_USER_015_REQUESTED; US_USER_015_SUCCEEDED; US_USER_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user for self-service; admin permission for administrative operations

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
