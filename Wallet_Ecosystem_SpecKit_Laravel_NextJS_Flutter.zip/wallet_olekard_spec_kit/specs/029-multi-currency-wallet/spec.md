# E29 — Multi-Currency Wallet

## Intent
This feature specification decomposes Epic E29 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-MCW-001 — Create currency wallet (P2)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Create currency wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/multi-currency/create-currency-wallet`

**DB Entities:** Wallet, Currency, FxRate, FxTransaction

**Events:** US_MCW_001_REQUESTED; US_MCW_001_SUCCEEDED; US_MCW_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-MCW-002 — Support multiple currencies (P2)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Support multiple currencies must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/multi-currency/support-multiple-currencies`

**DB Entities:** Wallet, Currency, FxRate, FxTransaction

**Events:** US_MCW_002_REQUESTED; US_MCW_002_SUCCEEDED; US_MCW_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-MCW-003 — View currency balances (P2)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** View currency balances must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/multi-currency/view-currency-balances`

**DB Entities:** Wallet, Currency, FxRate, FxTransaction

**Events:** US_MCW_003_REQUESTED; US_MCW_003_SUCCEEDED; US_MCW_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-MCW-004 — Transfer between own currency wallets (P2)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Transfer between own currency wallets must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/multi-currency/transfer-between-own-currency-wallets`

**DB Entities:** Wallet, Currency, FxRate, FxTransaction

**Events:** US_MCW_004_REQUESTED; US_MCW_004_SUCCEEDED; US_MCW_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-MCW-005 — Configure exchange rate (P2)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Configure exchange rate must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/multi-currency/configure-exchange-rate`

**DB Entities:** Wallet, Currency, FxRate, FxTransaction

**Events:** US_MCW_005_REQUESTED; US_MCW_005_SUCCEEDED; US_MCW_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-MCW-006 — Calculate FX fee (P2)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Calculate FX fee must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/multi-currency/calculate-fx-fee`

**DB Entities:** Wallet, Currency, FxRate, FxTransaction

**Events:** US_MCW_006_REQUESTED; US_MCW_006_SUCCEEDED; US_MCW_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-MCW-007 — Execute currency conversion (P2)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Execute currency conversion must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/multi-currency/execute-currency-conversion`

**DB Entities:** Wallet, Currency, FxRate, FxTransaction

**Events:** US_MCW_007_REQUESTED; US_MCW_007_SUCCEEDED; US_MCW_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-MCW-008 — Record FX ledger entries (P2)
**Actor:** Wallet / Ledger service

**Acceptance Criteria:** Record FX ledger entries must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/multi-currency/record-fx-ledger-entries`

**DB Entities:** Wallet, Currency, FxRate, FxTransaction

**Events:** US_MCW_008_REQUESTED; US_MCW_008_SUCCEEDED; US_MCW_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-MCW-009 — Maintain FX transaction history (P2)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Maintain FX transaction history must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/multi-currency/maintain-fx-transaction-history`

**DB Entities:** Wallet, Currency, FxRate, FxTransaction

**Events:** US_MCW_009_REQUESTED; US_MCW_009_SUCCEEDED; US_MCW_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
