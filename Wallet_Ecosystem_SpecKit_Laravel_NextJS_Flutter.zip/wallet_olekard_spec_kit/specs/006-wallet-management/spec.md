# E06 — Wallet Management

## Intent
This feature specification decomposes Epic E06 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-WALLET-001 — Automatically create wallet (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Automatically create wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/automatically-create-wallet`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_001_REQUESTED; US_WALLET_001_SUCCEEDED; US_WALLET_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-002 — Assign wallet ID (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Assign wallet ID must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/assign-wallet-id`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_002_REQUESTED; US_WALLET_002_SUCCEEDED; US_WALLET_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-003 — Associate wallet with user (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Associate wallet with user must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/associate-wallet-with-user`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_003_REQUESTED; US_WALLET_003_SUCCEEDED; US_WALLET_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-004 — Set wallet currency (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Set wallet currency must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/set-wallet-currency`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_004_REQUESTED; US_WALLET_004_SUCCEEDED; US_WALLET_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-005 — Set wallet status (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Set wallet status must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/set-wallet-status`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_005_REQUESTED; US_WALLET_005_SUCCEEDED; US_WALLET_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-006 — Configure wallet limits (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Configure wallet limits must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/configure-wallet-limits`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_006_REQUESTED; US_WALLET_006_SUCCEEDED; US_WALLET_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-007 — View available balance (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** View available balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/view-available-balance`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_007_REQUESTED; US_WALLET_007_SUCCEEDED; US_WALLET_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-008 — View ledger balance (P0)
**Actor:** Wallet / Ledger service

**Acceptance Criteria:** View ledger balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/view-ledger-balance`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_008_REQUESTED; US_WALLET_008_SUCCEEDED; US_WALLET_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-009 — View held balance (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** View held balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/view-held-balance`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_009_REQUESTED; US_WALLET_009_SUCCEEDED; US_WALLET_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-010 — View pending balance (P1)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** View pending balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/view-pending-balance`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_010_REQUESTED; US_WALLET_010_SUCCEEDED; US_WALLET_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-011 — Calculate available balance (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Calculate available balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/calculate-available-balance`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_011_REQUESTED; US_WALLET_011_SUCCEEDED; US_WALLET_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-012 — Prevent transaction exceeding available balance (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Prevent transaction exceeding available balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/prevent-transaction-exceeding-available-balance`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_012_REQUESTED; US_WALLET_012_SUCCEEDED; US_WALLET_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-013 — Freeze wallet (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Freeze wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/freeze-wallet`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_013_REQUESTED; US_WALLET_013_SUCCEEDED; US_WALLET_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Privileged role + explicit action permission + maker-checker where configured

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-014 — Unfreeze wallet (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Unfreeze wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/unfreeze-wallet`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_014_REQUESTED; US_WALLET_014_SUCCEEDED; US_WALLET_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Privileged role + explicit action permission + maker-checker where configured

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-015 — Close wallet (P1)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Close wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/close-wallet`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_015_REQUESTED; US_WALLET_015_SUCCEEDED; US_WALLET_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-016 — Prevent transactions on frozen wallet (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Prevent transactions on frozen wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/prevent-transactions-on-frozen-wallet`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_016_REQUESTED; US_WALLET_016_SUCCEEDED; US_WALLET_016_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WALLET-017 — Maintain wallet status history (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Maintain wallet status history must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/wallets/maintain-wallet-status-history`

**DB Entities:** Wallet, WalletLimit, WalletStatusHistory

**Events:** US_WALLET_017_REQUESTED; US_WALLET_017_SUCCEEDED; US_WALLET_017_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
