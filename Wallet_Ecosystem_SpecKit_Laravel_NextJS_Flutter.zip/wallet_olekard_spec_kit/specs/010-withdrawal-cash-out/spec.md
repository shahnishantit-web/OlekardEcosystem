# E10 — Withdrawal / Cash-Out

## Intent
This feature specification decomposes Epic E10 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-WITHDRAW-001 — Initiate withdrawal (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Initiate withdrawal must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/initiate-withdrawal`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_001_REQUESTED; US_WITHDRAW_001_SUCCEEDED; US_WITHDRAW_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-002 — Select withdrawal channel (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Select withdrawal channel must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/select-withdrawal-channel`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_002_REQUESTED; US_WITHDRAW_002_SUCCEEDED; US_WITHDRAW_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-003 — Enter withdrawal amount (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Enter withdrawal amount must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/enter-withdrawal-amount`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_003_REQUESTED; US_WITHDRAW_003_SUCCEEDED; US_WITHDRAW_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-004 — Validate withdrawal limit (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Validate withdrawal limit must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/validate-withdrawal-limit`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_004_REQUESTED; US_WITHDRAW_004_SUCCEEDED; US_WITHDRAW_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-005 — Calculate withdrawal fee (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Calculate withdrawal fee must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/calculate-withdrawal-fee`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_005_REQUESTED; US_WITHDRAW_005_SUCCEEDED; US_WITHDRAW_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-006 — Perform risk check (P0)
**Actor:** Risk engine / authorized risk officer

**Acceptance Criteria:** Perform risk check must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/perform-risk-check`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_006_REQUESTED; US_WITHDRAW_006_SUCCEEDED; US_WITHDRAW_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-007 — Reserve funds (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Reserve funds must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/reserve-funds`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_007_REQUESTED; US_WITHDRAW_007_SUCCEEDED; US_WITHDRAW_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-008 — Send payout request (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Send payout request must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/send-payout-request`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_008_REQUESTED; US_WITHDRAW_008_SUCCEEDED; US_WITHDRAW_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-009 — Process successful payout (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Process successful payout must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/process-successful-payout`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_009_REQUESTED; US_WITHDRAW_009_SUCCEEDED; US_WITHDRAW_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-010 — Process failed payout (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Process failed payout must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/process-failed-payout`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_010_REQUESTED; US_WITHDRAW_010_SUCCEEDED; US_WITHDRAW_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-011 — Release reserved funds (P0)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Release reserved funds must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/release-reserved-funds`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_011_REQUESTED; US_WITHDRAW_011_SUCCEEDED; US_WITHDRAW_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-WITHDRAW-012 — Generate withdrawal receipt (P1)
**Actor:** Customer / authorized financial service

**Acceptance Criteria:** Generate withdrawal receipt must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/withdrawals/generate-withdrawal-receipt`

**DB Entities:** WithdrawalTransaction, Payment, WalletHold

**Events:** US_WITHDRAW_012_REQUESTED; US_WITHDRAW_012_SUCCEEDED; US_WITHDRAW_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
