# E12 — Agent Management

## Intent
This feature specification decomposes Epic E12 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-AGENT-001 — Submit agent application (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Submit agent application must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/submit-agent-application`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_001_REQUESTED; US_AGENT_001_SUCCEEDED; US_AGENT_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-002 — Capture agent personal information (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Capture agent personal information must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/capture-agent-personal-information`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_002_REQUESTED; US_AGENT_002_SUCCEEDED; US_AGENT_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-003 — Capture business information (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Capture business information must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/capture-business-information`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_003_REQUESTED; US_AGENT_003_SUCCEEDED; US_AGENT_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-004 — Upload agent documents (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Upload agent documents must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/upload-agent-documents`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_004_REQUESTED; US_AGENT_004_SUCCEEDED; US_AGENT_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-005 — Perform agent KYC (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Perform agent KYC must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/perform-agent-kyc`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_005_REQUESTED; US_AGENT_005_SUCCEEDED; US_AGENT_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-006 — Approve agent (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Approve agent must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/approve-agent`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_006_REQUESTED; US_AGENT_006_SUCCEEDED; US_AGENT_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Privileged role + explicit action permission + maker-checker where configured

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-007 — Reject agent (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Reject agent must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/reject-agent`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_007_REQUESTED; US_AGENT_007_SUCCEEDED; US_AGENT_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-008 — Suspend agent (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Suspend agent must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/suspend-agent`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_008_REQUESTED; US_AGENT_008_SUCCEEDED; US_AGENT_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Privileged role + explicit action permission + maker-checker where configured

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-009 — Reactivate agent (P1)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Reactivate agent must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/reactivate-agent`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_009_REQUESTED; US_AGENT_009_SUCCEEDED; US_AGENT_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-010 — Search customer (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Search customer must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/search-customer`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_010_REQUESTED; US_AGENT_010_SUCCEEDED; US_AGENT_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-011 — Register customer (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Register customer must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/register-customer`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_011_REQUESTED; US_AGENT_011_SUCCEEDED; US_AGENT_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-012 — Initiate customer KYC (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Initiate customer KYC must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/initiate-customer-kyc`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_012_REQUESTED; US_AGENT_012_SUCCEEDED; US_AGENT_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-013 — View customer wallet status (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** View customer wallet status must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/view-customer-wallet-status`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_013_REQUESTED; US_AGENT_013_SUCCEEDED; US_AGENT_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-014 — View permitted customer transactions (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** View permitted customer transactions must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/view-permitted-customer-transactions`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_014_REQUESTED; US_AGENT_014_SUCCEEDED; US_AGENT_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGENT-015 — Prevent unauthorized customer data access (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Prevent unauthorized customer data access must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agents/prevent-unauthorized-customer-data-access`

**DB Entities:** Agent, AgentApplication, User, CustomerRelationship

**Events:** US_AGENT_015_REQUESTED; US_AGENT_015_SUCCEEDED; US_AGENT_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
