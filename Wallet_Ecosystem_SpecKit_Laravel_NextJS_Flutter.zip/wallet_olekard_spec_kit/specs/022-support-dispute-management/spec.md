# E22 — Support & Dispute Management

## Intent
This feature specification decomposes Epic E22 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-SUPPORT-001 — Create support request (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Create support request must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/support/create-support-request`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_SUPPORT_001_REQUESTED; US_SUPPORT_001_SUCCEEDED; US_SUPPORT_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-SUPPORT-002 — View support requests (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** View support requests must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/support/view-support-requests`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_SUPPORT_002_REQUESTED; US_SUPPORT_002_SUCCEEDED; US_SUPPORT_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-SUPPORT-003 — Assign support request (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Assign support request must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/support/assign-support-request`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_SUPPORT_003_REQUESTED; US_SUPPORT_003_SUCCEEDED; US_SUPPORT_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-SUPPORT-004 — Update support status (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Update support status must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/support/update-support-status`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_SUPPORT_004_REQUESTED; US_SUPPORT_004_SUCCEEDED; US_SUPPORT_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-SUPPORT-005 — Add support notes (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Add support notes must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/support/add-support-notes`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_SUPPORT_005_REQUESTED; US_SUPPORT_005_SUCCEEDED; US_SUPPORT_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DISPUTE-001 — Raise transaction dispute (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Raise transaction dispute must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/disputes/raise-transaction-dispute`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_DISPUTE_001_REQUESTED; US_DISPUTE_001_SUCCEEDED; US_DISPUTE_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DISPUTE-002 — Select dispute reason (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Select dispute reason must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/disputes/select-dispute-reason`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_DISPUTE_002_REQUESTED; US_DISPUTE_002_SUCCEEDED; US_DISPUTE_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DISPUTE-003 — Attach evidence (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Attach evidence must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/disputes/attach-evidence`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_DISPUTE_003_REQUESTED; US_DISPUTE_003_SUCCEEDED; US_DISPUTE_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DISPUTE-004 — Investigate dispute (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Investigate dispute must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/disputes/investigate-dispute`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_DISPUTE_004_REQUESTED; US_DISPUTE_004_SUCCEEDED; US_DISPUTE_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DISPUTE-005 — Approve dispute (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Approve dispute must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/disputes/approve-dispute`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_DISPUTE_005_REQUESTED; US_DISPUTE_005_SUCCEEDED; US_DISPUTE_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Privileged role + explicit action permission + maker-checker where configured

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DISPUTE-006 — Reject dispute (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Reject dispute must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/disputes/reject-dispute`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_DISPUTE_006_REQUESTED; US_DISPUTE_006_SUCCEEDED; US_DISPUTE_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DISPUTE-007 — Refund disputed transaction (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Refund disputed transaction must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/disputes/refund-disputed-transaction`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_DISPUTE_007_REQUESTED; US_DISPUTE_007_SUCCEEDED; US_DISPUTE_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Privileged role + explicit action permission + maker-checker where configured

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-DISPUTE-008 — Escalate dispute (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Escalate dispute must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/disputes/escalate-dispute`

**DB Entities:** SupportTicket, Dispute, DisputeEvidence

**Events:** US_DISPUTE_008_REQUESTED; US_DISPUTE_008_SUCCEEDED; US_DISPUTE_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
