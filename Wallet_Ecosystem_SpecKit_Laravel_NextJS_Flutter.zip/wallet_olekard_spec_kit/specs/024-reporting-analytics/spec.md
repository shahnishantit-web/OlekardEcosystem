# E24 — Reporting & Analytics

## Intent
This feature specification decomposes Epic E24 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-REPORT-001 — User report (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** User report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/user-report`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_001_REQUESTED; US_REPORT_001_SUCCEEDED; US_REPORT_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-002 — Wallet report (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Wallet report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/wallet-report`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_002_REQUESTED; US_REPORT_002_SUCCEEDED; US_REPORT_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-003 — Transaction report (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Transaction report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/transaction-report`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_003_REQUESTED; US_REPORT_003_SUCCEEDED; US_REPORT_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-004 — Agent report (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Agent report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/agent-report`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_004_REQUESTED; US_REPORT_004_SUCCEEDED; US_REPORT_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-005 — Commission report (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Commission report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/commission-report`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_005_REQUESTED; US_REPORT_005_SUCCEEDED; US_REPORT_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-006 — KYC report (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** KYC report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/kyc-report`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_006_REQUESTED; US_REPORT_006_SUCCEEDED; US_REPORT_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-007 — Reconciliation report (P0)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Reconciliation report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/reconciliation-report`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_007_REQUESTED; US_REPORT_007_SUCCEEDED; US_REPORT_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-008 — Settlement report (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Settlement report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/settlement-report`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_008_REQUESTED; US_REPORT_008_SUCCEEDED; US_REPORT_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-009 — Risk report (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Risk report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/risk-report`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_009_REQUESTED; US_REPORT_009_SUCCEEDED; US_REPORT_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-010 — Financial summary (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Financial summary must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/financial-summary`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_010_REQUESTED; US_REPORT_010_SUCCEEDED; US_REPORT_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-011 — Export CSV (P1)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Export CSV must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/export-csv`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_011_REQUESTED; US_REPORT_011_SUCCEEDED; US_REPORT_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-012 — Export Excel (P2)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Export Excel must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/export-excel`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_012_REQUESTED; US_REPORT_012_SUCCEEDED; US_REPORT_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-REPORT-013 — Schedule reports (P2)
**Actor:** Authorized operations/admin user or system

**Acceptance Criteria:** Schedule reports must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/reports/schedule-reports`

**DB Entities:** ReportDefinition, ReportJob, ReportExport

**Events:** US_REPORT_013_REQUESTED; US_REPORT_013_SUCCEEDED; US_REPORT_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** admin.read / admin.write as applicable; maker-checker for financial changes

**UI Screens:** Admin Portal: dashboard/list/detail/action/confirmation screens as applicable

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
