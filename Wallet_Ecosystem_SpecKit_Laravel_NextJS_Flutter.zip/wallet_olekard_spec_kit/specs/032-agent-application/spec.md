# E32 — Agent Application

## Intent
This feature specification decomposes Epic E32 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-AGAPP-001 — Agent login (P0)
**Actor:** Agent

**Acceptance Criteria:** Agent login must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/agent-login`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_001_REQUESTED; US_AGAPP_001_SUCCEEDED; US_AGAPP_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-002 — Agent logout (P0)
**Actor:** Agent

**Acceptance Criteria:** Agent logout must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/agent-logout`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_002_REQUESTED; US_AGAPP_002_SUCCEEDED; US_AGAPP_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-003 — Agent PIN reset (P0)
**Actor:** Agent

**Acceptance Criteria:** Agent PIN reset must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/agent-pin-reset`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_003_REQUESTED; US_AGAPP_003_SUCCEEDED; US_AGAPP_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-004 — View float (P0)
**Actor:** Agent

**Acceptance Criteria:** View float must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/view-float`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_004_REQUESTED; US_AGAPP_004_SUCCEEDED; US_AGAPP_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-005 — View daily transactions (P0)
**Actor:** Agent

**Acceptance Criteria:** View daily transactions must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/view-daily-transactions`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_005_REQUESTED; US_AGAPP_005_SUCCEEDED; US_AGAPP_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-006 — View commissions (P0)
**Actor:** Agent

**Acceptance Criteria:** View commissions must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/view-commissions`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_006_REQUESTED; US_AGAPP_006_SUCCEEDED; US_AGAPP_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-007 — Search customer (P0)
**Actor:** Agent

**Acceptance Criteria:** Search customer must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/search-customer`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_007_REQUESTED; US_AGAPP_007_SUCCEEDED; US_AGAPP_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-008 — Register customer (P0)
**Actor:** Agent

**Acceptance Criteria:** Register customer must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/register-customer`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_008_REQUESTED; US_AGAPP_008_SUCCEEDED; US_AGAPP_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-009 — Initiate KYC (P0)
**Actor:** Agent

**Acceptance Criteria:** Initiate KYC must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/initiate-kyc`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_009_REQUESTED; US_AGAPP_009_SUCCEEDED; US_AGAPP_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-010 — View customer status (P0)
**Actor:** Agent

**Acceptance Criteria:** View customer status must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/view-customer-status`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_010_REQUESTED; US_AGAPP_010_SUCCEEDED; US_AGAPP_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-011 — Cash-in (P0)
**Actor:** Agent

**Acceptance Criteria:** Cash-in must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/cash-in`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_011_REQUESTED; US_AGAPP_011_SUCCEEDED; US_AGAPP_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-012 — Cash-out (P0)
**Actor:** Agent

**Acceptance Criteria:** Cash-out must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/cash-out`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_012_REQUESTED; US_AGAPP_012_SUCCEEDED; US_AGAPP_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-013 — View transaction history (P0)
**Actor:** Agent

**Acceptance Criteria:** View transaction history must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/view-transaction-history`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_013_REQUESTED; US_AGAPP_013_SUCCEEDED; US_AGAPP_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-014 — Generate receipt (P0)
**Actor:** Agent

**Acceptance Criteria:** Generate receipt must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/generate-receipt`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_014_REQUESTED; US_AGAPP_014_SUCCEEDED; US_AGAPP_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-015 — View float (P0)
**Actor:** Agent

**Acceptance Criteria:** View float must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/view-float`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_015_REQUESTED; US_AGAPP_015_SUCCEEDED; US_AGAPP_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-016 — Request float funding (P0)
**Actor:** Agent

**Acceptance Criteria:** Request float funding must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/request-float-funding`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_016_REQUESTED; US_AGAPP_016_SUCCEEDED; US_AGAPP_016_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-017 — View float history (P0)
**Actor:** Agent

**Acceptance Criteria:** View float history must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/view-float-history`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_017_REQUESTED; US_AGAPP_017_SUCCEEDED; US_AGAPP_017_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-018 — View commission (P0)
**Actor:** Agent

**Acceptance Criteria:** View commission must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/view-commission`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_018_REQUESTED; US_AGAPP_018_SUCCEEDED; US_AGAPP_018_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-AGAPP-019 — View commission history (P0)
**Actor:** Agent

**Acceptance Criteria:** View commission history must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-app/view-commission-history`

**DB Entities:** Agent, Customer, Wallet, Transaction

**Events:** US_AGAPP_019_REQUESTED; US_AGAPP_019_SUCCEEDED; US_AGAPP_019_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Agent App: relevant operational screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
