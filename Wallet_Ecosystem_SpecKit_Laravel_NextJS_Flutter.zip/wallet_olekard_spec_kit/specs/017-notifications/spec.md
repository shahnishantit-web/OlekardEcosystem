# E17 — Notifications

## Intent
This feature specification decomposes Epic E17 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-NOTIFY-001 — Create notification (P0)
**Actor:** System

**Acceptance Criteria:** Create notification must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/create-notification`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_001_REQUESTED; US_NOTIFY_001_SUCCEEDED; US_NOTIFY_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-NOTIFY-002 — Send push notification (P0)
**Actor:** System

**Acceptance Criteria:** Send push notification must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/send-push-notification`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_002_REQUESTED; US_NOTIFY_002_SUCCEEDED; US_NOTIFY_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-NOTIFY-003 — Send SMS (P0)
**Actor:** System

**Acceptance Criteria:** Send SMS must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/send-sms`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_003_REQUESTED; US_NOTIFY_003_SUCCEEDED; US_NOTIFY_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-NOTIFY-004 — Send email (P1)
**Actor:** System

**Acceptance Criteria:** Send email must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/send-email`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_004_REQUESTED; US_NOTIFY_004_SUCCEEDED; US_NOTIFY_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-NOTIFY-005 — Send in-app notification (P0)
**Actor:** System

**Acceptance Criteria:** Send in-app notification must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/send-in-app-notification`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_005_REQUESTED; US_NOTIFY_005_SUCCEEDED; US_NOTIFY_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-NOTIFY-006 — Track notification status (P1)
**Actor:** System

**Acceptance Criteria:** Track notification status must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/track-notification-status`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_006_REQUESTED; US_NOTIFY_006_SUCCEEDED; US_NOTIFY_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-NOTIFY-007 — Retry failed notification (P1)
**Actor:** System

**Acceptance Criteria:** Retry failed notification must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/retry-failed-notification`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_007_REQUESTED; US_NOTIFY_007_SUCCEEDED; US_NOTIFY_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-NOTIFY-008 — Configure notification preferences (P1)
**Actor:** System

**Acceptance Criteria:** Configure notification preferences must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/configure-notification-preferences`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_008_REQUESTED; US_NOTIFY_008_SUCCEEDED; US_NOTIFY_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-NOTIFY-009 — Enable/disable marketing notifications (P1)
**Actor:** System

**Acceptance Criteria:** Enable/disable marketing notifications must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/enable-disable-marketing-notifications`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_009_REQUESTED; US_NOTIFY_009_SUCCEEDED; US_NOTIFY_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-NOTIFY-010 — Enforce mandatory financial notifications (P0)
**Actor:** System

**Acceptance Criteria:** Enforce mandatory financial notifications must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/notifications/enforce-mandatory-financial-notifications`

**DB Entities:** Notification, NotificationTemplate, NotificationPreference

**Events:** US_NOTIFY_010_REQUESTED; US_NOTIFY_010_SUCCEEDED; US_NOTIFY_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
