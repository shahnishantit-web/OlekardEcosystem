# E31 — Customer Application

## Intent
This feature specification decomposes Epic E31 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-CUST-001 — Register (P0)
**Actor:** Customer

**Acceptance Criteria:** Register must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/register`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_001_REQUESTED; US_CUST_001_SUCCEEDED; US_CUST_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-002 — Login (P0)
**Actor:** Customer

**Acceptance Criteria:** Login must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/login`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_002_REQUESTED; US_CUST_002_SUCCEEDED; US_CUST_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-003 — Logout (P0)
**Actor:** Customer

**Acceptance Criteria:** Logout must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/logout`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_003_REQUESTED; US_CUST_003_SUCCEEDED; US_CUST_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-004 — Reset PIN (P0)
**Actor:** Customer

**Acceptance Criteria:** Reset PIN must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/reset-pin`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_004_REQUESTED; US_CUST_004_SUCCEEDED; US_CUST_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-005 — Manage devices (P0)
**Actor:** Customer

**Acceptance Criteria:** Manage devices must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/manage-devices`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_005_REQUESTED; US_CUST_005_SUCCEEDED; US_CUST_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-006 — View wallet balance (P0)
**Actor:** Customer

**Acceptance Criteria:** View wallet balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/view-wallet-balance`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_006_REQUESTED; US_CUST_006_SUCCEEDED; US_CUST_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-007 — View recent transactions (P0)
**Actor:** Customer

**Acceptance Criteria:** View recent transactions must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/view-recent-transactions`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_007_REQUESTED; US_CUST_007_SUCCEEDED; US_CUST_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-008 — View shortcuts (P0)
**Actor:** Customer

**Acceptance Criteria:** View shortcuts must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/view-shortcuts`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_008_REQUESTED; US_CUST_008_SUCCEEDED; US_CUST_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-009 — View notifications (P0)
**Actor:** Customer

**Acceptance Criteria:** View notifications must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/view-notifications`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_009_REQUESTED; US_CUST_009_SUCCEEDED; US_CUST_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-010 — View wallet (P0)
**Actor:** Customer

**Acceptance Criteria:** View wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/view-wallet`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_010_REQUESTED; US_CUST_010_SUCCEEDED; US_CUST_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-011 — Add money (P0)
**Actor:** Customer

**Acceptance Criteria:** Add money must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/add-money`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_011_REQUESTED; US_CUST_011_SUCCEEDED; US_CUST_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-012 — Send money (P0)
**Actor:** Customer

**Acceptance Criteria:** Send money must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/send-money`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_012_REQUESTED; US_CUST_012_SUCCEEDED; US_CUST_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-013 — Receive money (P0)
**Actor:** Customer

**Acceptance Criteria:** Receive money must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/receive-money`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_013_REQUESTED; US_CUST_013_SUCCEEDED; US_CUST_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-014 — Withdraw money (P0)
**Actor:** Customer

**Acceptance Criteria:** Withdraw money must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/withdraw-money`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_014_REQUESTED; US_CUST_014_SUCCEEDED; US_CUST_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-015 — Browse services (P1)
**Actor:** Customer

**Acceptance Criteria:** Browse services must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/browse-services`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_015_REQUESTED; US_CUST_015_SUCCEEDED; US_CUST_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-016 — Purchase service (P1)
**Actor:** Customer

**Acceptance Criteria:** Purchase service must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/purchase-service`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_016_REQUESTED; US_CUST_016_SUCCEEDED; US_CUST_016_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-017 — View service history (P1)
**Actor:** Customer

**Acceptance Criteria:** View service history must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/view-service-history`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_017_REQUESTED; US_CUST_017_SUCCEEDED; US_CUST_017_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-018 — View profile (P0)
**Actor:** Customer

**Acceptance Criteria:** View profile must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/view-profile`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_018_REQUESTED; US_CUST_018_SUCCEEDED; US_CUST_018_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-019 — Edit profile (P0)
**Actor:** Customer

**Acceptance Criteria:** Edit profile must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/edit-profile`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_019_REQUESTED; US_CUST_019_SUCCEEDED; US_CUST_019_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-020 — Manage security (P0)
**Actor:** Customer

**Acceptance Criteria:** Manage security must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/manage-security`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_020_REQUESTED; US_CUST_020_SUCCEEDED; US_CUST_020_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-021 — Contact support (P1)
**Actor:** Customer

**Acceptance Criteria:** Contact support must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/contact-support`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_021_REQUESTED; US_CUST_021_SUCCEEDED; US_CUST_021_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-022 — Raise dispute (P1)
**Actor:** Customer

**Acceptance Criteria:** Raise dispute must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/raise-dispute`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_022_REQUESTED; US_CUST_022_SUCCEEDED; US_CUST_022_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-CUST-023 — Track dispute (P1)
**Actor:** Customer

**Acceptance Criteria:** Track dispute must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/customer/track-dispute`

**DB Entities:** User, Wallet, Transaction, Notification

**Events:** US_CUST_023_REQUESTED; US_CUST_023_SUCCEEDED; US_CUST_023_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** Customer App: relevant flow screen, confirmation/result screen, error state

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
