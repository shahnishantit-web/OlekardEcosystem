# E11 — Transaction Management

## Intent
This feature specification decomposes Epic E11 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-TXN-001 — Create transaction (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Create transaction must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/create-transaction`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_001_REQUESTED; US_TXN_001_SUCCEEDED; US_TXN_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-002 — Assign unique transaction ID (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Assign unique transaction ID must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/assign-unique-transaction-id`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_002_REQUESTED; US_TXN_002_SUCCEEDED; US_TXN_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-003 — Assign transaction reference (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Assign transaction reference must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/assign-transaction-reference`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_003_REQUESTED; US_TXN_003_SUCCEEDED; US_TXN_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-004 — Track transaction status (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Track transaction status must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/track-transaction-status`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_004_REQUESTED; US_TXN_004_SUCCEEDED; US_TXN_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-005 — Maintain transaction state history (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Maintain transaction state history must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/maintain-transaction-state-history`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_005_REQUESTED; US_TXN_005_SUCCEEDED; US_TXN_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-006 — View transaction history (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** View transaction history must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/view-transaction-history`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_006_REQUESTED; US_TXN_006_SUCCEEDED; US_TXN_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-007 — Filter by transaction type (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Filter by transaction type must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/filter-by-transaction-type`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_007_REQUESTED; US_TXN_007_SUCCEEDED; US_TXN_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-008 — Filter by date (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Filter by date must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/filter-by-date`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_008_REQUESTED; US_TXN_008_SUCCEEDED; US_TXN_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-009 — Filter by status (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Filter by status must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/filter-by-status`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_009_REQUESTED; US_TXN_009_SUCCEEDED; US_TXN_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-010 — Search transaction (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Search transaction must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/search-transaction`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_010_REQUESTED; US_TXN_010_SUCCEEDED; US_TXN_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-011 — View transaction details (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** View transaction details must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/view-transaction-details`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_011_REQUESTED; US_TXN_011_SUCCEEDED; US_TXN_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-012 — Download transaction receipt (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Download transaction receipt must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/download-transaction-receipt`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_012_REQUESTED; US_TXN_012_SUCCEEDED; US_TXN_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-013 — Share transaction receipt (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Share transaction receipt must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/share-transaction-receipt`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_013_REQUESTED; US_TXN_013_SUCCEEDED; US_TXN_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-014 — Request transaction reversal (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Request transaction reversal must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/request-transaction-reversal`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_014_REQUESTED; US_TXN_014_SUCCEEDED; US_TXN_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-015 — Approve reversal (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Approve reversal must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/approve-reversal`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_015_REQUESTED; US_TXN_015_SUCCEEDED; US_TXN_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Privileged role + explicit action permission + maker-checker where configured

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-016 — Reject reversal (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Reject reversal must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/reject-reversal`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_016_REQUESTED; US_TXN_016_SUCCEEDED; US_TXN_016_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-017 — Execute reversal through compensating ledger (P0)
**Actor:** Wallet / Ledger service

**Acceptance Criteria:** Execute reversal through compensating ledger must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/execute-reversal-through-compensating-ledger`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_017_REQUESTED; US_TXN_017_SUCCEEDED; US_TXN_017_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-018 — Process refund (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Process refund must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/process-refund`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_018_REQUESTED; US_TXN_018_SUCCEEDED; US_TXN_018_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Privileged role + explicit action permission + maker-checker where configured

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-TXN-019 — Audit reversal (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Audit reversal must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/transactions/audit-reversal`

**DB Entities:** Transaction, TransactionStatusHistory, Reversal

**Events:** US_TXN_019_REQUESTED; US_TXN_019_SUCCEEDED; US_TXN_019_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
