# E13 — Agent Float

## Intent
This feature specification decomposes Epic E13 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-FLOAT-001 — Create agent float wallet (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Create agent float wallet must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/create-agent-float-wallet`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_001_REQUESTED; US_FLOAT_001_SUCCEEDED; US_FLOAT_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FLOAT-002 — View float balance (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** View float balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/view-float-balance`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_002_REQUESTED; US_FLOAT_002_SUCCEEDED; US_FLOAT_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FLOAT-003 — Fund agent float (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Fund agent float must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/fund-agent-float`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_003_REQUESTED; US_FLOAT_003_SUCCEEDED; US_FLOAT_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FLOAT-004 — Cash-in using agent float (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Cash-in using agent float must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/cash-in-using-agent-float`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_004_REQUESTED; US_FLOAT_004_SUCCEEDED; US_FLOAT_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FLOAT-005 — Cash-out using agent float (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Cash-out using agent float must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/cash-out-using-agent-float`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_005_REQUESTED; US_FLOAT_005_SUCCEEDED; US_FLOAT_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FLOAT-006 — Validate agent float balance (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Validate agent float balance must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/validate-agent-float-balance`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_006_REQUESTED; US_FLOAT_006_SUCCEEDED; US_FLOAT_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FLOAT-007 — Prevent float overdraft (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Prevent float overdraft must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/prevent-float-overdraft`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_007_REQUESTED; US_FLOAT_007_SUCCEEDED; US_FLOAT_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FLOAT-008 — Configure agent float limits (P1)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Configure agent float limits must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/configure-agent-float-limits`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_008_REQUESTED; US_FLOAT_008_SUCCEEDED; US_FLOAT_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FLOAT-009 — Monitor low float (P1)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Monitor low float must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/monitor-low-float`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_009_REQUESTED; US_FLOAT_009_SUCCEEDED; US_FLOAT_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-FLOAT-010 — Generate agent float report (P1)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Generate agent float report must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/agent-float/generate-agent-float-report`

**DB Entities:** Wallet, FloatTransaction, FloatLimit

**Events:** US_FLOAT_010_REQUESTED; US_FLOAT_010_SUCCEEDED; US_FLOAT_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated user + resource-specific read permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
