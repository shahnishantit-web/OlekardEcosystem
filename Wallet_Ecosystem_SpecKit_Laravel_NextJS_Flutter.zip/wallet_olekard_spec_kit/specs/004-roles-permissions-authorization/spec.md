# E04 — Roles, Permissions & Authorization

## Intent
This feature specification decomposes Epic E04 from the approved 538-story backlog into an independently executable Spec-Kit feature.

## Scope
Implement only the stories listed in this document. Preserve their IDs and business intent.

## Platform alignment
- Backend API: Laravel/PHP 8.4+
- Admin/Web: Next.js + TypeScript where UI applies
- Mobile: Flutter where UI applies
- DB: PostgreSQL
- Cache/Queue: Redis + Horizon
- API: REST/OpenAPI
- Design: shared token-driven design system

## Decision handling
- Do not invent TBD values.
- Configurable policies must be resolved through the centralized Admin configuration capability.
- Financial stories must use ledger/idempotency/concurrency controls where applicable.
- Provider selection remains TBD.

## Epic Stories

### US-RBAC-001 — Create role (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Create role must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/create-role`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_001_REQUESTED; US_RBAC_001_SUCCEEDED; US_RBAC_001_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-002 — Update role (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Update role must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/update-role`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_002_REQUESTED; US_RBAC_002_SUCCEEDED; US_RBAC_002_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-003 — Disable role (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Disable role must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/disable-role`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_003_REQUESTED; US_RBAC_003_SUCCEEDED; US_RBAC_003_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-004 — Assign role to user (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Assign role to user must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/assign-role-to-user`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_004_REQUESTED; US_RBAC_004_SUCCEEDED; US_RBAC_004_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-005 — Remove role from user (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Remove role from user must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/remove-role-from-user`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_005_REQUESTED; US_RBAC_005_SUCCEEDED; US_RBAC_005_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-006 — Assign multiple roles (P1)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Assign multiple roles must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/assign-multiple-roles`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_006_REQUESTED; US_RBAC_006_SUCCEEDED; US_RBAC_006_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-007 — Create permission (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Create permission must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/create-permission`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_007_REQUESTED; US_RBAC_007_SUCCEEDED; US_RBAC_007_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-008 — Assign permission to role (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Assign permission to role must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/assign-permission-to-role`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_008_REQUESTED; US_RBAC_008_SUCCEEDED; US_RBAC_008_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-009 — Remove permission (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Remove permission must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/remove-permission`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_009_REQUESTED; US_RBAC_009_SUCCEEDED; US_RBAC_009_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-010 — Check API authorization (P0)
**Actor:** System / integration client

**Acceptance Criteria:** Check API authorization must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/check-api-authorization`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_010_REQUESTED; US_RBAC_010_SUCCEEDED; US_RBAC_010_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-011 — Check module authorization (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Check module authorization must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/check-module-authorization`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_011_REQUESTED; US_RBAC_011_SUCCEEDED; US_RBAC_011_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-012 — Check feature authorization (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Check feature authorization must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/check-feature-authorization`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_012_REQUESTED; US_RBAC_012_SUCCEEDED; US_RBAC_012_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-013 — Enforce transaction-level permission (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Enforce transaction-level permission must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/enforce-transaction-level-permission`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_013_REQUESTED; US_RBAC_013_SUCCEEDED; US_RBAC_013_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-014 — Determine modules available to user (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Determine modules available to user must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/determine-modules-available-to-user`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_014_REQUESTED; US_RBAC_014_SUCCEEDED; US_RBAC_014_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-015 — Restrict Customer to customer modules (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Restrict Customer to customer modules must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/restrict-customer-to-customer-modules`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_015_REQUESTED; US_RBAC_015_SUCCEEDED; US_RBAC_015_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-016 — Restrict Agent to agent modules (P0)
**Actor:** Agent or authorized admin

**Acceptance Criteria:** Restrict Agent to agent modules must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/restrict-agent-to-agent-modules`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_016_REQUESTED; US_RBAC_016_SUCCEEDED; US_RBAC_016_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-017 — Restrict Admin functions (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Restrict Admin functions must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/restrict-admin-functions`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_017_REQUESTED; US_RBAC_017_SUCCEEDED; US_RBAC_017_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing

### US-RBAC-018 — Support granular administrative permissions (P0)
**Actor:** Authenticated user / authorized system actor

**Acceptance Criteria:** Support granular administrative permissions must satisfy the source formal specification, including validation, authorization, persistence, traceability/audit and applicable financial integrity/idempotency requirements.

**API:** `/v1/iam/support-granular-administrative-permissions`

**DB Entities:** Role, Permission, UserRole, RolePermission

**Events:** US_RBAC_018_REQUESTED; US_RBAC_018_SUCCEEDED; US_RBAC_018_FAILED (where applicable); AUDIT_EVENT_RECORDED

**Permissions:** Authenticated actor + feature-specific permission

**UI Screens:** No dedicated UI if service-only; otherwise consuming application screen + loading, success and error states

**QA Scenarios:** Happy-path test with valid data. | Required-field and invalid-format validation test. | Unauthorized-role/access test. | Boundary/limit test where applicable. | Failure/timeout/provider-error test where applicable. | Duplicate/idempotency test where applicable. | Audit/event verification. | Regression test for dependent modules.

**Definition of Done:** Criteria + API/DB/events/security/QA implemented and passing


## Epic-level Definition of Done
- All stories in this epic meet their story-specific Definition of Done.
- Cross-story dependencies are tested.
- API contracts and migrations are reviewed.
- Security and authorization checks pass.
- UI states and accessibility requirements pass where applicable.
- No unresolved Critical/High defect blocks completion.
